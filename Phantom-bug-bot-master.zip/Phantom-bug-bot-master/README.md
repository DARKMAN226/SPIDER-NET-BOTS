<h1 align="center">Phantom-bug-bot</h1>

<p align="center">
  <a href="https://gihtub.com/Passkey-md">

</p>

<p align="center">
  <a href="https://github.com/Passkey-md/Phantom-bug-bot/fork">
    <img src="https://img.shields.io/github/forks/Passkey-md/Phantom-bug-bot?label=Fork&style=social">
    
    
  <a href="https://github.com/Passkey-md/Phantom-bug-bot/stargazers"> 
    <img src="https://img.shields.io/github/stars/Passkey-md?style=social">
  </a>

</p>


<p align="center">
<a href="https://github.com/Passkey-md"><img title="Owner" src="https://img.shields.io/badge/Owner-Phantom-blue.svg?style=for-the-badge&logo=github" width="185px"

</p>


### Termux Command guide 

 ```bash
termux-setup-storage
apt update
apt upgrade
pkg update && pkg upgrade
pkg install python
pkg install python2
pkg install bash
pkg install libwebp
pkg install git -y
pkg install nodejs -y 
pkg install ffmpeg -y 
pkg install wget
pkg install imagemagick -y
git clone https://github.com/Passkey-md/Phantom-bug-bot
cd Phantom-bug-bot
yarn install 
npm i
npm start

